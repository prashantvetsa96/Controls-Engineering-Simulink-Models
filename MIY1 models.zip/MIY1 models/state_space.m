m = 0.01;
k= 1;
b = 0.04;
%state-space sys definition
A = [0,1;-k/m,-b/m];
B = [0;1/m];
C = [1,0];
D = [0];
%checking controllability
Pc = ctrb(A,B);
nc = rank(Pc);
%checking observability
Po = obsv(A,C);
no = rank(Po);
% conditions
n = length(A);
n
det(Pc)
det(Po)
Po
no
Pc
nc
%%Closed loop controller design
% Openloop poles
sys = ss(A,B,C,D);
poles = eig(A);
poles
step(sys)
hold on
stepinfo(sys)
sisotool(sys);
%Gain matrix
p = [-15 + 9.798i,-15 - 9.798i];
k = place(A,B,p);
k
% closed loop system
A_cl = A-B*k;
sys_cl = ss(A_cl,(1/0.312)*B,C,D);
step(sys_cl)
stepinfo(sys)
stepinfo(sys_cl)
hold on
legend('open loop','closed loop')
hold off