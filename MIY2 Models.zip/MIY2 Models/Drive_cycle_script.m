clc
%% Energy per km calculation script
delta=1.097; %Mass factor of vehicle
fr=0.015; %Roll resistance friction
Cd=0.25; %Aerodynamic drag
Af=1.8; %Frontal area in m^2
g=9.81; %Gravitational acceleration in m/s^2
rho=1.2; %Air density in kg/m^3
mass=100:100:5500;
n=length(mass); %required for the weight sweep loop
color=['b+','g*','rh','ko','m-']; %plots each cycle in different style
%%
%Outer Loop
for j=1:5
    switch (j)
     case 1
     load CYC_US06;
     step_size = 1e-2;
     Gain=1;
     case 2
     load CYC_UDDS;
     step_size = 0.022795;
     Gain=1;
     case 3
     load WLTP3;
     step_size = 0.0299667;
     Gain=0.621371;
     case 4
     load EPA;
     step_size = 0.01274542;
     Gain=1;
     case 5
     load NYDC;
     step_size = 0.00996672;
     Gain=1;
     end
simtime=length(cyc_mph);
j
%Inner loop (Simulation loop)
 for i=1:n
Mv=mass(i);
m_eq=delta*Mv; %Equivalent mass of vehicle in kg
simout = sim('drive_cycle',simtime);
Avg_array(:,n*(j-1)+i) = simout.AVG.data(:,1); 
Energy_array(:,n*(j-1)+i)= simout.Energy.data(:,1);
Dis_array(:,n*(j-1)+i)=simout.Distance.data(:,1);
 end
end
%%
%Plotting
figure(1)
for p=1:5 %plotting loop
    a=n*(p-1);
    plot(mass(1:n),Avg_array(60101,a+1:a+n),color((p*2)-1:(p*2)),'MarkerSize',5)
    hold on %this holds the data through each iteration
end
legend('US06','UUDS','WLTP3','EPA','NYDC');
xlabel('Weight (in Kgs)');
ylabel('Ave Energy Consumption per Km (in W-hr/Km)');
axis([100,5500,0,800]);
hold off