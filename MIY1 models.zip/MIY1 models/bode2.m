clear all 
clc

s= tf('s');
k=1;
H = (1/(s^3+7*(s^2)+5*s+9))*k;
allmargin(H)
figure(1);
margin(H);
charac_eqn = 1+H;
figure(2);
pzmap(charac_eqn);