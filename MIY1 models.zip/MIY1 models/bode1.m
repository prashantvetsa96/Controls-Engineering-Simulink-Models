clear all
clc

F1 = tf([10],[1]);
F2 = tf([1 0],[1]);
F3 = tf([1],[5 1]);
F4 = tf([10 0],[5 1]);
figure(1);
bode(F1);
figure(2);
bode(F2);
figure(3);
bode(F3);
figure(4);
bode(F4);
margin(F4);