%system parameters
m = 0.01;
zeta = 0.2;
wn = 10;
R = 1;
%controller parameters
kp = 14;
ki = 10;
kd = 2;
%transfer function
s = tf('s');
C = kp+(ki/s)+(kd*s);
G = (1/m)/(s^2+2*zeta*wn*s+wn^2);
G
C
H = G*C*R/(1+C*G); %closed loop transfer fn
step(G,10)
hold on 
step(H,10)
legend('open loop','closed loop')
hold off
stepinfo(G)
stepinfo(H)
