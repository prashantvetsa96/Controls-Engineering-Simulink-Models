Mv=1310;
grade=6; %percent grade 
delta=1.097; %mass factor of the car 
m_eq=delta*Mv; %equivalent mass of the car including the rotating elements in kg 
Gr=4.5; %fixed gear ratio 
fr=0.015; %coefficient of rolling resistance 
Cd=0.25; %drag coefficient 
Af=1.8; %frontal area in m^2 
r=(15*0.0254+(2*0.155*0.6))/2; %15inch tires in m 
nu=0.87; %drivetrain efficiency 
% Declaring Constants 
g=9.81; %acceleration due to gravity in m/s^2 
rho=1.2;
%Conversion Factors 
mph2mps=1.6/3.6; 
kmph2mph=1/1.6; 
rpm2radps=pi/30; 
kmph2mps=1/3.6; 
% Performance Data 
vmax=81*mph2mps; %maximum velocity converted to m/s 
vgrade=45*mph2mps; %grade velocity converted to m/s
vacc=60*mph2mps; %velocity at peak acc converted to m/s 
tacc=11.5;

%%At Max Acc
%Calculating each load force 
Faero=0.5*Cd*Af*rho*vacc^2; %aerodynamic resistance N 
Froll=Mv*g*fr*cos(0); %rolling resistance N 
Facc=m_eq*(vacc)/tacc; %acceleration force is non zero N 
Fgrade=Mv*g*sin(0); %grade is 0 N 
%Calculating the net torque and power from motor 
F_max_acc_wheel=Faero+Fgrade+Froll+Facc; %net force at wheels N 
T_max_acc_wheel=F_max_acc_wheel*r; %net torque at wheels Nm 
T_max_acc_motor=T_max_acc_wheel/(Gr*nu); %net torque at motor divided by gear ratio and efficiency Nm 
n_max_acc_motor=(vacc/r)*Gr; %maximum motor speed rad/s 
P_max_acc_motor=T_max_acc_motor*n_max_acc_motor; %maximum motor power W
%%At Max vel
%Calculating each load force
Faero=0.5*Cd*Af*rho*vmax^2; %aerodynamic resistanc 
Froll=Mv*g*fr*cos(0); %rolling resistance 
Facc=m_eq*0; %acceleration force is zero as the velocity is constant 
Fgrade=Mv*g*sin(0); %grade is 0 
%Calculating the net torque and power from motor 
F_max_vel_wheel=Faero+Fgrade+Froll+Facc; %net force at wheels 
T_max_vel_wheel=F_max_vel_wheel*r; %net torque at wheels 
T_max_vel_motor=T_max_vel_wheel/(Gr*nu); %net torque at motor divided by gear ratio and efficiency 
n_max_vel_motor=(vmax/r)*Gr; %maximum motor speed 
P_max_vel_motor=T_max_vel_motor*n_max_vel_motor; %maximum motor
%%At Max Grade
%Calculating each load force 
Faero=0.5*Cd*Af*rho*vgrade^2; %aerodynamic resistance N 
Froll=Mv*g*fr*cos(atan(grade/100)); %rolling resistance N 
Facc=m_eq*0 ; %acceleration force is zero as the velocity is constant N 
Fgrade=Mv*g*sin(atan(grade/100)); %grade is 6% 
%Calculating the net torque and power from motor 
F_grade_wheel=Faero+Fgrade+Froll+Facc; %net force at wheels N 
T_grade_wheel=F_grade_wheel*r; %net torque at wheels Nm 
T_grade_motor=T_grade_wheel/(Gr*nu); %net torque at motor divided by gear ratio and efficiency Nm 
n_grade_motor=(vgrade/r)*Gr; %maximum motor speed rad/s 
P_grade_motor=T_grade_motor*n_grade_motor; %maximum motor power W
%%Maximum of the 3 calculations 
[T_max,I_maxT]=max([T_grade_motor,T_max_vel_motor,T_max_acc_motor]); %Max torque and the index to identify for which case the torque is max 
n_max=max([n_grade_motor/rpm2radps,n_max_vel_motor/rpm2radps,n_max_acc_motor/rpm2radps]); %Max speed 
[P_max,I_maxP]=max([n_grade_motor*T_grade_motor,n_max_vel_motor*T_max_vel_motor,n_max_acc_motor*T_max_acc_motor]); %Max power and the index to identify for which case the power is max
%%Results
fprintf('Tmax_motor = %d Nm\n',T_max); 
fprintf('Pmax_motor = %d W\n',P_max); 
fprintf('nmax_motor = %d rpm\n',n_max);

%% Battery sizing 
%Declaring the known 
V_max=124;%maximum voltage of the battery in V 
V_nom=106; %nominal voltage of the battery in V 
Range=105;
AVG=1.637753e+02; %W-hr/km 
fprintf('Energy consumed per km = %d W-hr/km\n',AVG);
E_total=AVG*Range; %calculation of the total energy requirement W-hr
%Declaring Cell Constants 
cell_Vnom=3.6; %nominal voltage of each cell in V 
cell_capacity=3.2; %capacity of each cell in A.h 
cell_energy=11.52; %energy of each cell in W-hr

N_series=V_nom/cell_Vnom; %no of cells in series to develop required voltage 
Energy_series=N_series*cell_energy; %energy in one series 
N_parallel=E_total/Energy_series; %no of cells in parallel 
Capacity_battery=N_parallel*cell_capacity; %capacity of battery pack 
Energy_total=Capacity_battery*V_nom; %total energy of the battery 
N_total=N_series*N_parallel; % total number of cells in the bettery pack

fprintf('Energy of battpack = %d W-hr\n',Energy_total); 
fprintf('Capacity of battpack = %d A-hr\n',Capacity_battery); 
fprintf('No of cells = %d\n',N_total);