s= tf('s');
k = 40;
G = (1/(s^3+7*s^2+5*s+9))*k;
roots([1 7 5 9])
nyquist(G)
grid on